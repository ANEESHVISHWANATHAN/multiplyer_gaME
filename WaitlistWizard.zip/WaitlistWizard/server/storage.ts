import { 
  users, 
  type User, 
  type InsertUser, 
  lobbies, 
  type Lobby, 
  type InsertLobby,
  players,
  type Player,
  type InsertPlayer,
  waitlist,
  type Waitlist,
  type InsertWaitlist
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Lobby methods
  createLobby(code: string, gameType: string): Promise<Lobby>;
  getLobby(id: number): Promise<Lobby | undefined>;
  getLobbyByCode(code: string): Promise<Lobby | undefined>;
  updateLobby(id: number, updates: Partial<Lobby>): Promise<Lobby>;
  removeLobby(id: number): Promise<void>;
  
  // Player methods
  createPlayer(player: Partial<InsertPlayer>): Promise<Player>;
  getPlayer(id: number): Promise<Player | undefined>;
  getPlayersByLobbyId(lobbyId: number): Promise<Player[]>;
  updatePlayer(id: number, updates: Partial<Player>): Promise<Player>;
  removePlayer(id: number): Promise<void>;
  
  // Waitlist methods
  addToWaitlist(email: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Lobby methods
  async createLobby(code: string, gameType: string): Promise<Lobby> {
    // Using a dummy hostId of 0 initially - will be updated when player is created
    const [lobby] = await db.insert(lobbies).values({
      code,
      hostId: 0,
      gameType,
      status: 'waiting'
    }).returning();
    
    return lobby;
  }
  
  async getLobby(id: number): Promise<Lobby | undefined> {
    const [lobby] = await db.select().from(lobbies).where(eq(lobbies.id, id));
    return lobby || undefined;
  }
  
  async getLobbyByCode(code: string): Promise<Lobby | undefined> {
    // Use ilike for case-insensitive comparison
    const [lobby] = await db
      .select()
      .from(lobbies)
      .where(eq(lobbies.code, code.toUpperCase()));
    
    return lobby || undefined;
  }
  
  async updateLobby(id: number, updates: Partial<Lobby>): Promise<Lobby> {
    const [updatedLobby] = await db
      .update(lobbies)
      .set(updates)
      .where(eq(lobbies.id, id))
      .returning();
    
    if (!updatedLobby) {
      throw new Error(`Lobby with ID ${id} not found`);
    }
    
    return updatedLobby;
  }
  
  async removeLobby(id: number): Promise<void> {
    // First remove all players in this lobby
    await db
      .delete(players)
      .where(eq(players.lobbyId, id));
    
    // Then remove the lobby
    await db
      .delete(lobbies)
      .where(eq(lobbies.id, id));
  }
  
  // Player methods
  async createPlayer(partialPlayer: Partial<InsertPlayer>): Promise<Player> {
    if (!partialPlayer.lobbyId) {
      throw new Error('Lobby ID is required when creating a player');
    }
    
    // Create player with default values for any missing fields
    const playerData = {
      lobbyId: partialPlayer.lobbyId,
      name: partialPlayer.name || 'Player',
      isHost: partialPlayer.isHost || false,
    };
    
    const [player] = await db
      .insert(players)
      .values(playerData)
      .returning();
    
    // If this player is a host, update the lobby's hostId
    if (player.isHost) {
      await this.updateLobby(player.lobbyId, { hostId: player.id });
    }
    
    return player;
  }
  
  async getPlayer(id: number): Promise<Player | undefined> {
    const [player] = await db
      .select()
      .from(players)
      .where(eq(players.id, id));
    
    return player || undefined;
  }
  
  async getPlayersByLobbyId(lobbyId: number): Promise<Player[]> {
    return db
      .select()
      .from(players)
      .where(eq(players.lobbyId, lobbyId));
  }
  
  async updatePlayer(id: number, updates: Partial<Player>): Promise<Player> {
    const [updatedPlayer] = await db
      .update(players)
      .set(updates)
      .where(eq(players.id, id))
      .returning();
    
    if (!updatedPlayer) {
      throw new Error(`Player with ID ${id} not found`);
    }
    
    // If player is becoming a host, update the lobby
    if (updates.isHost && !updatedPlayer.isHost) {
      await this.updateLobby(updatedPlayer.lobbyId, { hostId: updatedPlayer.id });
    }
    
    return updatedPlayer;
  }
  
  async removePlayer(id: number): Promise<void> {
    await db
      .delete(players)
      .where(eq(players.id, id));
  }
  
  // Waitlist methods
  async addToWaitlist(email: string): Promise<void> {
    await db.insert(waitlist).values({ email }).onConflictDoNothing();
  }
}

export const storage = new DatabaseStorage();
