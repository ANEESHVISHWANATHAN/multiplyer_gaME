import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { storage } from "./storage";
import { generateRoomCode } from "../client/src/lib/utils";
import { WebSocketMessage } from "@shared/schema";

interface ConnectedClient {
  ws: WebSocket;
  playerId?: number;
  lobbyId?: number;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Keep track of connected clients
  const clients = new Map<WebSocket, ConnectedClient>();
  
  // Set up WebSocket connection handler
  wss.on('connection', (ws: WebSocket) => {
    console.log('WebSocket client connected');
    
    // Add client to our map
    clients.set(ws, { ws });
    
    // Handle messages from clients
    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message) as WebSocketMessage;
        
        switch (data.type) {
          case 'CREATE_LOBBY': {
            const { playerName, gameType } = data;
            
            // Generate a unique room code
            const roomCode = generateRoomCode();
            
            // Create a new lobby
            const lobby = await storage.createLobby(roomCode, gameType);
            
            // Create a new player as the host
            const player = await storage.createPlayer({
              lobbyId: lobby.id,
              name: playerName,
              isHost: true
            });
            
            // Update clients map with player and lobby IDs
            clients.set(ws, { ws, playerId: player.id, lobbyId: lobby.id });
            
            // Send confirmation back to the client
            ws.send(JSON.stringify({
              type: 'LOBBY_CREATED',
              lobby,
              player
            }));
            
            break;
          }
          
          case 'JOIN_LOBBY': {
            const { playerName, roomCode } = data;
            
            // Find the lobby by room code
            const lobby = await storage.getLobbyByCode(roomCode);
            
            if (!lobby) {
              ws.send(JSON.stringify({
                type: 'ERROR',
                message: 'Lobby not found. Check the room code and try again.'
              }));
              break;
            }
            
            // Create a new player in the lobby (not as host)
            const player = await storage.createPlayer({
              lobbyId: lobby.id,
              name: playerName,
              isHost: false
            });
            
            // Update clients map with player and lobby IDs
            clients.set(ws, { ws, playerId: player.id, lobbyId: lobby.id });
            
            // Notify the new player they've joined
            ws.send(JSON.stringify({
              type: 'LOBBY_JOINED',
              lobby,
              player
            }));
            
            // Get all players in the lobby
            const lobbyPlayers = await storage.getPlayersByLobbyId(lobby.id);
            
            // Send updated lobby state to all clients in the lobby
            broadcastToLobby(lobby.id, {
              type: 'LOBBY_STATE',
              lobby,
              players: lobbyPlayers
            });
            
            // Notify other players that someone new joined
            broadcastToLobby(lobby.id, {
              type: 'PLAYER_JOINED',
              player
            }, [player.id]); // Exclude the new player from this broadcast
            
            break;
          }
          
          case 'LEAVE_LOBBY': {
            const { playerId } = data;
            const client = clients.get(ws);
            
            if (!client || !client.lobbyId) break;
            
            // Get the player and lobby info
            const player = await storage.getPlayer(playerId);
            if (!player) break;
            
            const lobbyId = player.lobbyId;
            
            // Remove player from storage
            await storage.removePlayer(playerId);
            
            // Check if player was host
            if (player.isHost) {
              // Get remaining players in the lobby
              const remainingPlayers = await storage.getPlayersByLobbyId(lobbyId);
              
              if (remainingPlayers.length > 0) {
                // Assign a new host
                const newHost = remainingPlayers[0];
                await storage.updatePlayer(newHost.id, { isHost: true });
                
                // Notify the new host
                const newHostClient = findClientByPlayerId(newHost.id);
                if (newHostClient) {
                  newHostClient.ws.send(JSON.stringify({
                    type: 'PLAYER_HOST_CHANGED',
                    playerId: newHost.id,
                    isHost: true
                  }));
                }
              } else {
                // If no players left, remove the lobby
                await storage.removeLobby(lobbyId);
              }
            }
            
            // Update client's data
            clients.set(ws, { ws });
            
            // Notify other players in the lobby
            broadcastToLobby(lobbyId, {
              type: 'PLAYER_LEFT',
              playerId
            });
            
            // Send updated lobby state to all clients
            const lobby = await storage.getLobby(lobbyId);
            if (lobby) {
              const lobbyPlayers = await storage.getPlayersByLobbyId(lobbyId);
              broadcastToLobby(lobbyId, {
                type: 'LOBBY_STATE',
                lobby,
                players: lobbyPlayers
              });
            }
            
            break;
          }
          
          case 'TOGGLE_READY': {
            const { playerId, isReady } = data;
            
            // Update player ready state
            await storage.updatePlayer(playerId, { isReady });
            
            // Get player's lobby
            const player = await storage.getPlayer(playerId);
            if (!player) break;
            
            // Broadcast the ready status change to all clients in the lobby
            broadcastToLobby(player.lobbyId, {
              type: 'PLAYER_READY_CHANGED',
              playerId,
              isReady
            });
            
            break;
          }
          
          case 'START_GAME': {
            const { lobbyId } = data;
            const client = clients.get(ws);
            
            if (!client || !client.playerId) break;
            
            // Verify the player is the host
            const player = await storage.getPlayer(client.playerId);
            if (!player || !player.isHost) {
              ws.send(JSON.stringify({
                type: 'ERROR',
                message: 'Only the host can start the game'
              }));
              break;
            }
            
            // Check if all players are ready
            const lobbyPlayers = await storage.getPlayersByLobbyId(lobbyId);
            const allReady = lobbyPlayers.every(p => p.isReady);
            
            if (!allReady) {
              ws.send(JSON.stringify({
                type: 'ERROR',
                message: 'All players must be ready to start the game'
              }));
              break;
            }
            
            // Update lobby status
            await storage.updateLobby(lobbyId, { status: 'started' });
            
            // Broadcast game start to all clients in the lobby
            broadcastToLobby(lobbyId, {
              type: 'GAME_STARTED',
              lobbyId
            });
            
            break;
          }
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'ERROR',
          message: 'Failed to process request'
        }));
      }
    });
    
    // Handle disconnections
    ws.on('close', async () => {
      const client = clients.get(ws);
      
      if (client && client.playerId) {
        // Get the player before removing
        const player = await storage.getPlayer(client.playerId);
        
        if (player) {
          const lobbyId = player.lobbyId;
          
          // Update player connection status or remove them
          await storage.updatePlayer(client.playerId, { 
            connectionStatus: 'disconnected' 
          });
          
          // Notify other clients in the lobby
          broadcastToLobby(lobbyId, {
            type: 'PLAYER_LEFT',
            playerId: client.playerId
          });
          
          // If player was host, assign a new host
          if (player.isHost) {
            const lobbyPlayers = await storage.getPlayersByLobbyId(lobbyId);
            const remainingPlayers = lobbyPlayers.filter(p => p.id !== client.playerId);
            
            if (remainingPlayers.length > 0) {
              const newHost = remainingPlayers[0];
              await storage.updatePlayer(newHost.id, { isHost: true });
              
              // Notify the lobby of host change
              broadcastToLobby(lobbyId, {
                type: 'PLAYER_HOST_CHANGED',
                playerId: newHost.id,
                isHost: true
              });
            } else {
              // Remove the lobby if no players left
              await storage.removeLobby(lobbyId);
            }
          }
          
          // Send updated lobby state
          const lobby = await storage.getLobby(lobbyId);
          if (lobby) {
            const lobbyPlayers = await storage.getPlayersByLobbyId(lobbyId);
            broadcastToLobby(lobbyId, {
              type: 'LOBBY_STATE',
              lobby,
              players: lobbyPlayers
            });
          }
        }
      }
      
      // Remove client from our map
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });
  });
  
  // Helper function to broadcast to all clients in a lobby
  function broadcastToLobby(lobbyId: number, data: any, excludePlayerIds: number[] = []) {
    clients.forEach((client) => {
      if (
        client.lobbyId === lobbyId && 
        client.ws.readyState === WebSocket.OPEN &&
        (!client.playerId || !excludePlayerIds.includes(client.playerId))
      ) {
        client.ws.send(JSON.stringify(data));
      }
    });
  }
  
  // Helper function to find a client by player ID
  function findClientByPlayerId(playerId: number): ConnectedClient | undefined {
    for (const [_, client] of clients.entries()) {
      if (client.playerId === playerId) {
        return client;
      }
    }
    return undefined;
  }
  
  // API endpoint for waitlist signups
  app.post('/api/waitlist', async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: 'Email is required' });
      }
      
      // Store email in waitlist (simplified for this demo)
      await storage.addToWaitlist(email);
      
      res.status(200).json({ message: 'Successfully added to waitlist' });
    } catch (error) {
      console.error('Waitlist error:', error);
      res.status(500).json({ message: 'Failed to add to waitlist' });
    }
  });

  return httpServer;
}
