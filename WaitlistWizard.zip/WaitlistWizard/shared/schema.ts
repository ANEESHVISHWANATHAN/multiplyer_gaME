import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const lobbies = pgTable("lobbies", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  hostId: integer("host_id").notNull(),
  gameType: text("game_type").notNull(),
  status: text("status").notNull().default("waiting"), // waiting, started, ended
});

export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  lobbyId: integer("lobby_id").notNull(),
  name: text("name").notNull(),
  isHost: boolean("is_host").notNull().default(false),
  isReady: boolean("is_ready").notNull().default(false),
  connectionStatus: text("connection_status").notNull().default("connected"), // connected, disconnected
});

export const waitlist = pgTable("waitlist", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertLobbySchema = createInsertSchema(lobbies).pick({
  code: true,
  hostId: true,
  gameType: true,
});

export const insertPlayerSchema = createInsertSchema(players).pick({
  lobbyId: true,
  name: true,
  isHost: true,
});

export const insertWaitlistSchema = createInsertSchema(waitlist).pick({
  email: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertLobby = z.infer<typeof insertLobbySchema>;
export type Lobby = typeof lobbies.$inferSelect;

export type InsertPlayer = z.infer<typeof insertPlayerSchema>;
export type Player = typeof players.$inferSelect;

export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
export type Waitlist = typeof waitlist.$inferSelect;

// Shared message types for WebSocket communication
export type WebSocketMessage = 
  | { type: 'CREATE_LOBBY'; playerName: string; gameType: string; }
  | { type: 'JOIN_LOBBY'; playerName: string; roomCode: string; }
  | { type: 'LEAVE_LOBBY'; playerId: number; }
  | { type: 'TOGGLE_READY'; playerId: number; isReady: boolean; }
  | { type: 'START_GAME'; lobbyId: number; }
  | { type: 'LOBBY_STATE'; lobby: Lobby; players: Player[]; }
  | { type: 'ERROR'; message: string; }
  | { type: 'PLAYER_JOINED'; player: Player; }
  | { type: 'PLAYER_LEFT'; playerId: number; }
  | { type: 'PLAYER_READY_CHANGED'; playerId: number; isReady: boolean; }
  | { type: 'LOBBY_CREATED'; lobby: Lobby; player: Player; }
  | { type: 'LOBBY_JOINED'; lobby: Lobby; player: Player; }
  | { type: 'GAME_STARTED'; lobbyId: number; };
