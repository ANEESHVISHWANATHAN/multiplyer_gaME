# Bingo Multiplayer Game

A real-time multiplayer Bingo game with lobby system using WebSockets and PostgreSQL database.

## Features

- Create and join game lobbies
- Real-time player interaction via WebSockets
- Persistent game data with PostgreSQL
- Player ready states and game status tracking
- Game host controls for starting games
- Responsive UI that works on desktop and mobile

## Tech Stack

- **Frontend**: React, TailwindCSS, shadcn/ui components
- **Backend**: Express, WebSockets (ws)
- **Database**: PostgreSQL with Drizzle ORM
- **Build Tools**: Vite, esbuild

## Deploying to Render

This application can be easily deployed to Render using the following steps:

### 1. Create a PostgreSQL Database on Render

- Log in to your Render account
- Go to "New" → "PostgreSQL"
- Configure your database:
  - Name: `bingo-db`
  - User: `bingo_user`
  - Database: `bingo`
  - Choose the region and plan that fits your needs
- Click "Create Database"
- Save the Connection String (Internal Database URL) for the next step

### 2. Deploy the Web Service

- Go to "New" → "Web Service"
- Connect your GitHub repository
- Configure your web service:
  - Name: `bingo-multiplayer`
  - Root Directory: Leave empty
  - Runtime: Node
  - Build Command: `npm ci && npm run build`
  - Start Command: `npm start`
- Add the following environment variables:
  - Key: `NODE_ENV` Value: `production`
  - Key: `DATABASE_URL` Value: `[Your Internal Database URL from Step 1]`
- Choose the region and plan that fits your needs
- Click "Create Web Service"

### 3. Initialize the Database

After deployment, you'll need to run the database migrations. To do this:

1. Set up and install the Render CLI: https://render.com/docs/cli
2. Connect to your web service using:
   ```bash
   render connect <service-id>
   ```
3. Run the database migration:
   ```bash
   npm run db:push
   ```

### Alternative: Using Blueprint (render.yaml)

This repository includes a `render.yaml` file for easier deployment using Render Blueprints:

1. Fork this repository to your GitHub account
2. Log in to Render and go to "Blueprints"
3. Click "New Blueprint Instance"
4. Connect your forked repository
5. Follow the prompts to deploy both the database and web service

## Local Development

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a PostgreSQL database and update the DATABASE_URL in the environment
4. Run database migrations:
   ```bash
   npm run db:push
   ```
5. Start the development server:
   ```bash
   npm run dev
   ```
6. Open your browser to http://localhost:5000

## WebSocket API

The WebSocket connection endpoint is at `/ws`. Messages are sent as JSON and include the following types:

- `CREATE_LOBBY`: Create a new game lobby
- `JOIN_LOBBY`: Join an existing lobby with a room code
- `LEAVE_LOBBY`: Leave the current lobby
- `TOGGLE_READY`: Set player ready status
- `START_GAME`: Begin the game (host only)
- `LOBBY_STATE`: Full state update (server → client)
- `ERROR`: Error message (server → client)

For more details on the WebSocket API, see the WebSocketMessage type in `shared/schema.ts`.