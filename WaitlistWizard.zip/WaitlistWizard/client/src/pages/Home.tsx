import React, { useState } from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import CreateLobbyModal from "@/components/CreateLobbyModal";
import JoinLobbyModal from "@/components/JoinLobbyModal";
import GameLobby from "@/components/GameLobby";
import FeatureShowcase from "@/components/FeatureShowcase";
import WaitlistSection from "@/components/WaitlistSection";
import Footer from "@/components/Footer";
import Toast from "@/components/Toast";
import ConnectionErrorModal from "@/components/ConnectionErrorModal";
import { useGame } from "@/contexts/GameContext";

export default function Home() {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const { lobby, isConnected, connectError } = useGame();
  
  return (
    <div className="min-h-screen flex flex-col bg-[#0F172A] text-[#F9FAFB]">
      <Header />
      
      <main className="container mx-auto px-4 py-8 md:py-16 flex-grow">
        {/* Show lobby if connected, otherwise show hero */}
        {lobby ? (
          <GameLobby />
        ) : (
          <>
            <Hero 
              onCreateLobby={() => setShowCreateModal(true)}
              onJoinLobby={() => setShowJoinModal(true)}
            />
            <FeatureShowcase />
            <WaitlistSection />
          </>
        )}
      </main>
      
      <Footer />
      
      {/* Modals */}
      <CreateLobbyModal 
        isOpen={showCreateModal} 
        onClose={() => setShowCreateModal(false)} 
      />
      
      <JoinLobbyModal 
        isOpen={showJoinModal} 
        onClose={() => setShowJoinModal(false)} 
      />
      
      <ConnectionErrorModal 
        isOpen={!isConnected && Boolean(connectError)} 
      />
    </div>
  );
}
