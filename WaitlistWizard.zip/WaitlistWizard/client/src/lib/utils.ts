import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Generates a random room code for game lobbies
 */
export function generateRoomCode(): string {
  // Exclude confusing characters like I, O, 0, 1
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

/**
 * Creates initials from a player name
 */
export function getInitials(name: string): string {
  if (!name) return '';
  
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  
  return name.slice(0, 2).toUpperCase();
}

/**
 * Generates a color based on the player's name
 */
export function getPlayerColor(name: string): string {
  if (!name) return 'hsl(var(--primary))';
  
  // Simple hash function for the name
  const hash = name.split('').reduce((acc, char) => {
    return acc + char.charCodeAt(0);
  }, 0);
  
  // Generate a hue value based on the hash, between 0 and 360
  const hue = hash % 360;
  
  return `hsl(${hue}, 70%, 50%)`;
}

/**
 * Checks if all players in a lobby are ready
 */
export function areAllPlayersReady(players: Array<{ isReady: boolean }>): boolean {
  if (!players.length) return false;
  return players.every(player => player.isReady);
}
