import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Player, Lobby, WebSocketMessage } from "@shared/schema";
import useWebSocket from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";

interface GameContextType {
  players: Player[];
  lobby: Lobby | null;
  currentPlayer: Player | null;
  isConnected: boolean;
  isHost: boolean;
  createLobby: (playerName: string, gameType: string) => void;
  joinLobby: (playerName: string, roomCode: string) => void;
  leaveLobby: () => void;
  toggleReady: () => void;
  startGame: () => void;
  copyRoomCode: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider = ({ children }: { children: ReactNode }) => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [lobby, setLobby] = useState<Lobby | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<Player | null>(null);
  const { toast } = useToast();

  const { 
    isConnected, 
    sendMessage, 
    lastMessage, 
    connectError 
  } = useWebSocket();

  const isHost = Boolean(currentPlayer?.isHost);
  
  // Parse and handle incoming WebSocket messages
  useEffect(() => {
    if (!lastMessage) return;
    
    try {
      const data = JSON.parse(lastMessage) as WebSocketMessage;
      
      switch (data.type) {
        case 'LOBBY_CREATED':
          setLobby(data.lobby);
          setCurrentPlayer(data.player);
          setPlayers([data.player]);
          // Save to localStorage
          localStorage.setItem('playerId', data.player.id.toString());
          localStorage.setItem('lobbyCode', data.lobby.code);
          break;
          
        case 'LOBBY_JOINED':
          setLobby(data.lobby);
          setCurrentPlayer(data.player);
          // Save to localStorage
          localStorage.setItem('playerId', data.player.id.toString());
          localStorage.setItem('lobbyCode', data.lobby.code);
          break;
          
        case 'LOBBY_STATE':
          setLobby(data.lobby);
          setPlayers(data.players);
          break;
          
        case 'PLAYER_JOINED':
          setPlayers(prev => [...prev, data.player]);
          toast({
            title: "Player Joined",
            description: `${data.player.name} has joined the lobby`,
          });
          break;
          
        case 'PLAYER_LEFT':
          setPlayers(prev => prev.filter(p => p.id !== data.playerId));
          toast({
            title: "Player Left",
            description: "A player has left the lobby",
          });
          break;
          
        case 'PLAYER_READY_CHANGED':
          setPlayers(prev => 
            prev.map(p => 
              p.id === data.playerId 
                ? { ...p, isReady: data.isReady } 
                : p
            )
          );
          break;
          
        case 'GAME_STARTED':
          toast({
            title: "Game Started!",
            description: "The game has been started by the host",
          });
          break;
          
        case 'ERROR':
          toast({
            title: "Error",
            description: data.message,
            variant: "destructive"
          });
          break;
      }
    } catch (err) {
      console.error("Failed to parse WebSocket message:", err);
    }
  }, [lastMessage, toast]);

  // Handle connection errors
  useEffect(() => {
    if (connectError) {
      toast({
        title: "Connection Error",
        description: connectError,
        variant: "destructive"
      });
    }
  }, [connectError, toast]);

  // Try to reconnect on page load if we have saved data
  useEffect(() => {
    const savedPlayerId = localStorage.getItem('playerId');
    const savedLobbyCode = localStorage.getItem('lobbyCode');
    
    if (isConnected && savedPlayerId && savedLobbyCode) {
      // Auto-reconnect logic could be implemented here
      // For now, we'll just clear localStorage on page refresh to avoid stale data
      localStorage.removeItem('playerId');
      localStorage.removeItem('lobbyCode');
    }
  }, [isConnected]);

  const createLobby = (playerName: string, gameType: string) => {
    sendMessage(JSON.stringify({
      type: 'CREATE_LOBBY',
      playerName,
      gameType
    }));
  };

  const joinLobby = (playerName: string, roomCode: string) => {
    sendMessage(JSON.stringify({
      type: 'JOIN_LOBBY',
      playerName,
      roomCode
    }));
  };

  const leaveLobby = () => {
    if (!currentPlayer) return;
    
    sendMessage(JSON.stringify({
      type: 'LEAVE_LOBBY',
      playerId: currentPlayer.id
    }));
    
    // Clear state and localStorage
    setLobby(null);
    setCurrentPlayer(null);
    setPlayers([]);
    localStorage.removeItem('playerId');
    localStorage.removeItem('lobbyCode');
  };

  const toggleReady = () => {
    if (!currentPlayer) return;
    
    const newReadyState = !currentPlayer.isReady;
    
    sendMessage(JSON.stringify({
      type: 'TOGGLE_READY',
      playerId: currentPlayer.id,
      isReady: newReadyState
    }));
    
    // Optimistically update the current player's state
    setCurrentPlayer({ ...currentPlayer, isReady: newReadyState });
  };

  const startGame = () => {
    if (!isHost || !lobby) return;
    
    sendMessage(JSON.stringify({
      type: 'START_GAME',
      lobbyId: lobby.id
    }));
  };

  const copyRoomCode = () => {
    if (!lobby) return;
    
    navigator.clipboard.writeText(lobby.code)
      .then(() => {
        toast({
          title: "Room Code Copied",
          description: "Room code copied to clipboard"
        });
      })
      .catch(err => {
        console.error('Could not copy text:', err);
        toast({
          title: "Error",
          description: "Could not copy room code",
          variant: "destructive"
        });
      });
  };

  return (
    <GameContext.Provider
      value={{
        players,
        lobby,
        currentPlayer,
        isConnected,
        isHost,
        createLobby,
        joinLobby,
        leaveLobby,
        toggleReady,
        startGame,
        copyRoomCode
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error("useGame must be used within a GameProvider");
  }
  return context;
};
