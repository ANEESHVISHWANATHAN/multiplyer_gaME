import React from "react";
import { Player } from "@shared/schema";
import { getInitials } from "@/lib/utils";

interface PlayerCardProps {
  player: Player;
  isCurrentPlayer: boolean;
}

export default function PlayerCard({ player, isCurrentPlayer }: PlayerCardProps) {
  const { name, isHost, isReady, connectionStatus } = player;
  
  return (
    <div className={`player-card bg-[#0F172A] rounded-lg p-4 ${isCurrentPlayer ? 'border-2 border-[#6D28D9]' : 'border border-gray-700'} relative`}>
      {isHost && (
        <div className="absolute top-3 right-3 flex items-center">
          <span className="text-xs font-medium uppercase bg-[#6D28D9] px-2 py-0.5 rounded text-white">Host</span>
        </div>
      )}
      
      <div className="flex items-center mb-3">
        <div className={`w-12 h-12 rounded-full ${isHost ? 'bg-[#6D28D9]' : 'bg-[#4C1D95]'} flex items-center justify-center text-lg font-bold mr-3`}>
          {getInitials(name)}
        </div>
        <div>
          <h4 className="font-medium text-white">{name}</h4>
          <p className={`text-xs ${connectionStatus === 'connected' ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
            <i className={`fas ${connectionStatus === 'connected' ? 'fa-wifi' : 'fa-wifi-slash'} mr-1`}></i>
            {connectionStatus === 'connected' ? 'Connected' : 'Disconnected'}
          </p>
        </div>
      </div>
      
      <div className="ready-status flex items-center justify-between">
        {isReady ? (
          <span className="text-sm font-medium text-[#10B981]">
            <i className="fas fa-check-circle mr-1"></i> Ready
          </span>
        ) : (
          <span className="text-sm font-medium text-gray-400">
            <i className="fas fa-times-circle mr-1"></i> Not Ready
          </span>
        )}
      </div>
    </div>
  );
}
