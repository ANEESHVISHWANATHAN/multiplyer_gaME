import React from "react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useGame } from "@/contexts/GameContext";

const formSchema = z.object({
  playerName: z.string().min(2, "Name must be at least 2 characters").max(15, "Name must be 15 characters or less"),
  roomCode: z.string().length(4, "Room code must be exactly 4 characters"),
});

type FormData = z.infer<typeof formSchema>;

interface JoinLobbyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function JoinLobbyModal({ isOpen, onClose }: JoinLobbyModalProps) {
  const { joinLobby } = useGame();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      playerName: "",
      roomCode: ""
    }
  });
  
  const onSubmit = (data: FormData) => {
    joinLobby(data.playerName, data.roomCode.toUpperCase());
    form.reset();
    onClose();
  };

  // Handle room code input to ensure uppercase
  const handleRoomCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toUpperCase();
    form.setValue("roomCode", value);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#1E293B] border-0 text-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white">Join a Lobby</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="playerName" className="text-sm font-medium text-gray-300">Your Name</Label>
              <Input
                id="playerName"
                placeholder="Enter your name"
                className="w-full px-4 py-3 bg-[#0F172A] border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#6D28D9]"
                {...form.register("playerName")}
              />
              {form.formState.errors.playerName && (
                <p className="text-red-500 text-xs mt-1">{form.formState.errors.playerName.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="roomCode" className="text-sm font-medium text-gray-300">Room Code</Label>
              <Input
                id="roomCode"
                placeholder="XXXX"
                maxLength={4}
                className="w-full px-4 py-3 bg-[#0F172A] border border-gray-700 rounded-lg text-white uppercase font-mono tracking-widest focus:outline-none focus:ring-2 focus:ring-[#6D28D9]"
                {...form.register("roomCode")}
                onChange={handleRoomCodeChange}
              />
              {form.formState.errors.roomCode && (
                <p className="text-red-500 text-xs mt-1">{form.formState.errors.roomCode.message}</p>
              )}
            </div>
          </div>
          
          <DialogFooter className="mt-6">
            <Button 
              type="button" 
              variant="ghost" 
              onClick={onClose}
              className="text-gray-300"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-[#6D28D9] hover:bg-[#5B21B6] text-white"
            >
              Join Lobby
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
