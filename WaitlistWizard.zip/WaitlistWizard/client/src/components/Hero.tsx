import React from "react";
import { Button } from "@/components/ui/button";

interface HeroProps {
  onCreateLobby: () => void;
  onJoinLobby: () => void;
}

export default function Hero({ onCreateLobby, onJoinLobby }: HeroProps) {
  return (
    <section className="mb-12 text-center" id="hero">
      <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white">
        Connect & Play <span className="text-[#8B5CF6]">Together</span>
      </h2>
      <p className="text-lg md:text-xl mb-8 text-gray-300 max-w-2xl mx-auto">
        Create a game lobby, invite your friends with a unique code, and start playing in seconds.
        No account required.
      </p>
      <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
        <Button 
          onClick={onCreateLobby}
          className="px-6 py-3 bg-[#6D28D9] hover:bg-[#5B21B6] text-white font-medium rounded-lg transition duration-300 flex items-center justify-center"
        >
          <i className="fas fa-plus mr-2"></i> Create a Lobby
        </Button>
        <Button 
          onClick={onJoinLobby}
          variant="outline"
          className="px-6 py-3 bg-[#1E293B] hover:bg-gray-700 text-white font-medium rounded-lg transition duration-300 flex items-center justify-center"
        >
          <i className="fas fa-sign-in-alt mr-2"></i> Join a Lobby
        </Button>
      </div>
      <p className="text-sm text-gray-400">No downloads required. Works on all devices.</p>
    </section>
  );
}
