import React from "react";
import { useGame } from "@/contexts/GameContext";
import PlayerCard from "@/components/PlayerCard";
import { Button } from "@/components/ui/button";
import { areAllPlayersReady } from "@/lib/utils";

export default function GameLobby() {
  const { 
    players, 
    lobby, 
    currentPlayer, 
    isHost, 
    isConnected,
    leaveLobby, 
    toggleReady, 
    startGame,
    copyRoomCode 
  } = useGame();

  // Create empty slots for remaining player capacity (up to 8 players)
  const emptySlots = Array(Math.max(0, 8 - players.length)).fill(null);
  
  // Determine if all players are ready
  const allPlayersReady = areAllPlayersReady(players);
  
  // Get current player ready status
  const isPlayerReady = currentPlayer?.isReady || false;

  return (
    <section>
      <div className="bg-[#1E293B] rounded-xl p-6 w-full max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Game Lobby</h2>
            <div className="flex items-center">
              <span className="text-sm text-gray-400 mr-2">Room Code:</span>
              <span className="game-code text-lg font-medium text-white bg-[#0F172A] px-3 py-1 rounded">
                {lobby?.code || "----"}
              </span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={copyRoomCode}
                className="ml-2 text-gray-400 hover:text-white"
              >
                <i className="far fa-copy"></i>
              </Button>
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="connection-status flex items-center mr-4">
              <span className={`inline-block w-2 h-2 rounded-full ${isConnected ? "bg-[#10B981]" : "bg-[#EF4444]"} mr-2 animate-pulse-slow`}></span>
              <span className={`text-sm ${isConnected ? "text-[#10B981]" : "text-[#EF4444]"}`}>
                {isConnected ? "Connected" : "Disconnected"}
              </span>
            </div>
            <div className="player-count text-sm text-gray-300">
              <i className="fas fa-users mr-1"></i> {players.length}/8
            </div>
          </div>
        </div>
        
        {/* Player Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Map through real players */}
          {players.map((player) => (
            <PlayerCard 
              key={player.id} 
              player={player}
              isCurrentPlayer={player.id === currentPlayer?.id}
            />
          ))}
          
          {/* Empty Slots */}
          {emptySlots.map((_, index) => (
            <div 
              key={`empty-${index}`}
              className="player-card bg-[#0F172A] rounded-lg p-4 border border-gray-700 border-dashed flex items-center justify-center min-h-[120px]"
            >
              <span className="text-gray-500">Waiting for player...</span>
            </div>
          ))}
        </div>
        
        {/* Host Controls */}
        <div className="host-controls flex justify-between items-center border-t border-gray-700 pt-6">
          <div className="flex items-center">
            {isHost && (
              <Button 
                variant="ghost" 
                className="mr-4 text-gray-300 hover:text-white flex items-center text-sm"
              >
                <i className="fas fa-cog mr-2"></i> Game Settings
              </Button>
            )}
            <Button 
              variant="ghost" 
              onClick={toggleReady}
              className="text-gray-300 hover:text-white flex items-center text-sm"
            >
              {isPlayerReady ? (
                <>
                  <i className="fas fa-check-circle mr-2 text-[#10B981]"></i> Ready
                </>
              ) : (
                <>
                  <i className="fas fa-times-circle mr-2 text-gray-400"></i> Not Ready
                </>
              )}
            </Button>
          </div>
          
          <div>
            <Button 
              variant="ghost" 
              onClick={leaveLobby}
              className="px-4 py-2 text-gray-300 hover:text-white text-sm mr-3"
            >
              Leave Lobby
            </Button>
            <Button 
              disabled={!isHost || !allPlayersReady || players.length < 2}
              onClick={startGame}
              className="px-6 py-2 bg-[#F59E0B] hover:bg-[#D97706] text-white font-medium rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Start Game
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
