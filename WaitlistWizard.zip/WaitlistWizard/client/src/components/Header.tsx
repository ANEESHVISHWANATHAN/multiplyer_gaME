import React from "react";

export default function Header() {
  return (
    <header className="w-full py-4 border-b border-[#1E293B]">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <div className="mr-3 w-10 h-10 rounded-full bg-[#6D28D9] flex items-center justify-center">
            <i className="fas fa-gamepad text-white"></i>
          </div>
          <h1 className="text-2xl font-bold text-white">GameSync</h1>
        </div>
        <div>
          <a href="#" className="hidden md:inline-block px-4 py-2 text-sm text-white hover:text-[#F59E0B] transition">How It Works</a>
          <a href="#" className="hidden md:inline-block px-4 py-2 text-sm text-white hover:text-[#F59E0B] transition">About</a>
          <a href="#" className="hidden md:inline-block px-4 py-2 text-sm text-white hover:text-[#F59E0B] transition">Support</a>
        </div>
      </div>
    </header>
  );
}
