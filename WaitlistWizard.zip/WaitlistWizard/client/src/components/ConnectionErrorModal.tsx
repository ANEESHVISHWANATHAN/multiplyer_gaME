import React from "react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import useWebSocket from "@/hooks/useWebSocket";

interface ConnectionErrorModalProps {
  isOpen: boolean;
}

export default function ConnectionErrorModal({ isOpen }: ConnectionErrorModalProps) {
  const { reconnect, connectError } = useWebSocket();

  const handleReconnect = () => {
    reconnect();
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="bg-[#1E293B] border-0 text-white">
        <DialogHeader className="text-center">
          <div className="w-16 h-16 bg-[#EF4444]/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-exclamation-triangle text-[#EF4444] text-2xl"></i>
          </div>
          <DialogTitle className="text-xl font-bold text-white mb-2">Connection Error</DialogTitle>
          <DialogDescription className="text-gray-300">
            {connectError || "Unable to establish WebSocket connection. Please check your network and try again."}
          </DialogDescription>
        </DialogHeader>
        
        <DialogFooter className="mt-4 flex justify-center">
          <Button 
            onClick={handleReconnect}
            className="px-6 py-2 bg-[#6D28D9] hover:bg-[#5B21B6] text-white font-medium rounded-lg transition"
          >
            Try Again
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
