import React from "react";

export default function FeatureShowcase() {
  return (
    <section className="py-12 md:py-20">
      <h2 className="text-2xl md:text-3xl font-bold mb-12 text-center text-white">How It Works</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="feature-card bg-[#1E293B] rounded-xl p-6 text-center">
          <div className="w-16 h-16 bg-[#6D28D9]/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-plus text-[#6D28D9] text-2xl"></i>
          </div>
          <h3 className="text-xl font-semibold mb-3 text-white">Create a Lobby</h3>
          <p className="text-gray-300">Create a new game lobby as a host and get a unique room code to share with friends.</p>
        </div>
        
        <div className="feature-card bg-[#1E293B] rounded-xl p-6 text-center">
          <div className="w-16 h-16 bg-[#6D28D9]/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-users text-[#6D28D9] text-2xl"></i>
          </div>
          <h3 className="text-xl font-semibold mb-3 text-white">Invite Players</h3>
          <p className="text-gray-300">Share your room code with friends on the same network to join your game lobby.</p>
        </div>
        
        <div className="feature-card bg-[#1E293B] rounded-xl p-6 text-center">
          <div className="w-16 h-16 bg-[#6D28D9]/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-gamepad text-[#6D28D9] text-2xl"></i>
          </div>
          <h3 className="text-xl font-semibold mb-3 text-white">Start Playing</h3>
          <p className="text-gray-300">Once everyone is ready, the host can start the game and play together in real-time.</p>
        </div>
      </div>
    </section>
  );
}
