import React from "react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useGame } from "@/contexts/GameContext";

const formSchema = z.object({
  playerName: z.string().min(2, "Name must be at least 2 characters").max(15, "Name must be 15 characters or less"),
  gameType: z.string(),
});

type FormData = z.infer<typeof formSchema>;

interface CreateLobbyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateLobbyModal({ isOpen, onClose }: CreateLobbyModalProps) {
  const { createLobby } = useGame();
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      playerName: "",
      gameType: "card-game"
    }
  });
  
  const onSubmit = (data: FormData) => {
    createLobby(data.playerName, data.gameType);
    form.reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#1E293B] border-0 text-white">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-white">Create a Lobby</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="playerName" className="text-sm font-medium text-gray-300">Your Name</Label>
              <Input
                id="playerName"
                placeholder="Enter your name"
                className="w-full px-4 py-3 bg-[#0F172A] border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#6D28D9]"
                {...form.register("playerName")}
              />
              {form.formState.errors.playerName && (
                <p className="text-red-500 text-xs mt-1">{form.formState.errors.playerName.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="gameType" className="text-sm font-medium text-gray-300">Game Type</Label>
              <Controller
                control={form.control}
                name="gameType"
                render={({ field }) => (
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <SelectTrigger className="w-full px-4 py-3 bg-[#0F172A] border border-gray-700 rounded-lg text-white">
                      <SelectValue placeholder="Select a game type" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0F172A] border border-gray-700 text-white">
                      <SelectItem value="card-game">Card Game</SelectItem>
                      <SelectItem value="board-game">Board Game</SelectItem>
                      <SelectItem value="trivia">Trivia</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
          </div>
          
          <DialogFooter className="mt-6">
            <Button 
              type="button" 
              variant="ghost" 
              onClick={onClose}
              className="text-gray-300"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="bg-[#6D28D9] hover:bg-[#5B21B6] text-white"
            >
              Create Lobby
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
