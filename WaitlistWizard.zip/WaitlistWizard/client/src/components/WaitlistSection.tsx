import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function WaitlistSection() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        title: "Error",
        description: "Please enter your email address",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await apiRequest('POST', '/api/waitlist', { email });
      
      toast({
        title: "Success!",
        description: "You've been added to our waitlist."
      });
      
      setEmail("");
    } catch (error) {
      console.error("Waitlist error:", error);
      toast({
        title: "Something went wrong",
        description: "We couldn't add you to the waitlist. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-12 md:py-20 bg-[#1E293B] rounded-xl my-12">
      <div className="max-w-3xl mx-auto px-6">
        <h2 className="text-2xl md:text-3xl font-bold mb-4 text-center text-white">Get Early Access</h2>
        <p className="text-center text-gray-300 mb-8">Join our waitlist to be the first to know when we release new game types and features!</p>
        
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            className="flex-1 px-4 py-3 bg-[#0F172A] border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#6D28D9]"
            required
          />
          <Button 
            type="submit" 
            disabled={isSubmitting}
            className="px-6 py-3 bg-[#6D28D9] hover:bg-[#5B21B6] text-white font-medium rounded-lg transition whitespace-nowrap"
          >
            {isSubmitting ? "Joining..." : "Join Waitlist"}
          </Button>
        </form>
        
        <p className="text-center text-gray-400 mt-4 text-sm">We'll keep you updated on our progress and never spam you.</p>
      </div>
    </section>
  );
}
