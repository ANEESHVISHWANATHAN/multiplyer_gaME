import React, { useEffect, useState } from "react";

interface ToastProps {
  message: string;
  duration?: number;
  type?: "success" | "error" | "info";
  onClose?: () => void;
}

export default function Toast({ 
  message, 
  duration = 3000, 
  type = "success", 
  onClose 
}: ToastProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      if (onClose) onClose();
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  if (!visible) return null;

  const getIcon = () => {
    switch (type) {
      case "success":
        return <i className="fas fa-check-circle text-[#10B981] mr-3"></i>;
      case "error":
        return <i className="fas fa-exclamation-circle text-[#EF4444] mr-3"></i>;
      case "info":
        return <i className="fas fa-info-circle text-[#3B82F6] mr-3"></i>;
      default:
        return <i className="fas fa-check-circle text-[#10B981] mr-3"></i>;
    }
  };

  return (
    <div className="fixed bottom-4 right-4 bg-[#1E293B] border border-gray-700 rounded-lg px-4 py-3 shadow-lg max-w-xs z-50">
      <div className="flex items-center">
        {getIcon()}
        <p className="text-white">{message}</p>
      </div>
    </div>
  );
}
