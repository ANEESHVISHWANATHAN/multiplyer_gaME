import React from "react";

export default function Footer() {
  return (
    <footer className="bg-[#1E293B] py-8 border-t border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:justify-between items-center mb-8">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="mr-3 w-8 h-8 rounded-full bg-[#6D28D9] flex items-center justify-center">
              <i className="fas fa-gamepad text-white text-sm"></i>
            </div>
            <h2 className="text-xl font-bold text-white">GameSync</h2>
          </div>
          
          <div className="flex items-center space-x-4">
            <a href="#" className="text-gray-400 hover:text-white transition" aria-label="Twitter">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition" aria-label="Discord">
              <i className="fab fa-discord"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition" aria-label="GitHub">
              <i className="fab fa-github"></i>
            </a>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-6 text-center">
          <p className="text-gray-400 text-sm">&copy; {new Date().getFullYear()} GameSync. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
