import { useState, useEffect, useRef, useCallback } from 'react';

const useWebSocket = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<string | null>(null);
  const [connectError, setConnectError] = useState<string | null>(null);
  const socketRef = useRef<WebSocket | null>(null);

  // Initialize WebSocket connection
  useEffect(() => {
    const connectWebSocket = () => {
      setConnectError(null);
      
      // Determine WebSocket protocol based on page protocol
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        console.log('WebSocket connection established');
        setIsConnected(true);
        setConnectError(null);
      };
      
      socket.onmessage = (event) => {
        setLastMessage(event.data);
      };
      
      socket.onclose = (event) => {
        console.log('WebSocket connection closed', event.code, event.reason);
        setIsConnected(false);
        
        // Attempt to reconnect after a delay, unless the closure was clean
        if (!event.wasClean) {
          setConnectError('Connection lost. Attempting to reconnect...');
          setTimeout(connectWebSocket, 5000);
        }
      };
      
      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnectError('Connection error occurred');
      };
      
      socketRef.current = socket;
    };
    
    connectWebSocket();
    
    // Cleanup function to close the WebSocket when the component unmounts
    return () => {
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, []);
  
  // Function to send messages through the WebSocket
  const sendMessage = useCallback((message: string) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(message);
    } else {
      setConnectError('Cannot send message: connection is not open');
    }
  }, []);
  
  // Function to manually reconnect
  const reconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.close();
    }
    setIsConnected(false);
    setConnectError(null);
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      console.log('WebSocket connection re-established');
      setIsConnected(true);
    };
    
    socket.onmessage = (event) => {
      setLastMessage(event.data);
    };
    
    socket.onclose = (event) => {
      console.log('WebSocket connection closed', event.code, event.reason);
      setIsConnected(false);
      
      if (!event.wasClean) {
        setConnectError('Connection lost');
      }
    };
    
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setConnectError('Connection error occurred');
    };
    
    socketRef.current = socket;
  }, []);

  return {
    isConnected,
    sendMessage,
    lastMessage,
    connectError,
    reconnect
  };
};

export default useWebSocket;
